<?php
include("../dbconnection.php");

if(isset($_REQUEST["disDrugRequest"])){
	$str = $_REQUEST["drugs"];
	$str = substr($str,1);
	//$searchKey = "bshab12";
	$batches = explode("=", $str);
	$uid = $_REQUEST["uid"];
	$date = date("Y-m-d");
	$query = "INSERT into requests (date,sending_dept,receiving_dept,	u_id,state,description) values ('$date','1','0','$uid','0','dispensary_drug_request');";
	mysqli_select_db($conn,"hospital");
	$res = mysqli_query($conn,$query);
	$ret = "";
	if($res){
		$query = "SELECT LAST_INSERT_ID();";
		$res = mysqli_query($conn,$query);
		if($res){
			$row=mysqli_fetch_array($res,MYSQLI_ASSOC);
			$query = "INSERT into request_details (request_id,serial_number,amount) values ";
			$id = $row["LAST_INSERT_ID()"];
			$data = "";
			for($i=0;$i<sizeof($batches);$i++) {
				$ro = explode("^", $batches[$i]);
				$data = $data."("."'".$id."'".","."'".$ro[0]."'".","."'".$ro[1]."'"."),";
			}
			$data = substr($data,0,-1);
			$query = $query.$data.";";
			$res = mysqli_query($conn,$query);
			if($res){
				$ret = "ok";
			}
		}
		
	}
	echo $ret;
	exit();
}


?>