<?php
include("../dbconnection.php");

if(isset($_REQUEST["nbatch_number"])){
	$searchKey = $_REQUEST["nbatch_number"];
	//$searchKey = "bshab12";
	$query = "SELECT serial_number from drug_batches where (batch_number='$searchKey' && deleted=0)";
	mysqli_select_db($conn,"hospital");
	$res = mysqli_query($conn,$query);
	$ret = "";
	if($res){
		$ret = "ok";
		if(mysqli_num_rows($res)!=0){
			$ret = "1";
		}
		
	}
	echo $ret;
	exit();
}
if(isset($_REQUEST["addArrival"])){
	$str = $_REQUEST["batches"];
	//$searchKey = "bshab12";
	$batches = explode("=", $str);
	$data = "";

	for($i=0;$i<sizeof($batches)-1;$i++) {
		$row = explode("^", $batches[$i]);
		$data = $data."("."'".$row[1]."'".","."'".$row[0]."'".","."'".substr($row[3],6)."-".substr($row[3],0,2)."-".substr($row[3],3,2)."'".","."'".substr($row[4],6)."-".substr($row[4],0,2)."-".substr($row[4],3,2)."'".","."'".$row[2]."'".","."'".$row[2]."'".","."'".$row[2]."'"."),";
	}
	$data = substr($data,0,-1);
	$query = "INSERT into drug_batches (batch_number,serial_number,arrival,expire,arrival_amount,inventory_balance,total_balance) values ";
	$query = $query.$data.";";
	mysqli_select_db($conn,"hospital");
	$res = mysqli_query($conn,$query);
	$ret = "";
	if($res){
		$ret = "ok";
	}
	echo $ret;
	exit();
}
if(isset($_REQUEST["invDrugRequest"])){
	$str = $_REQUEST["drugs"];
	$str = substr($str,1);
	//$searchKey = "bshab12";
	$batches = explode("=", $str);
	$uid = $_REQUEST["uid"];
	$date = date("Y-m-d");
	$query = "INSERT into requests (date,sending_dept,receiving_dept,	u_id,state,description) values ('$date','2','0','$uid','0','inventory_drug_request');";
	mysqli_select_db($conn,"hospital");
	$res = mysqli_query($conn,$query);
	$ret = "";
	if($res){
		$query = "SELECT LAST_INSERT_ID();";
		$res = mysqli_query($conn,$query);
		if($res){
			$row=mysqli_fetch_array($res,MYSQLI_ASSOC);
			$query = "INSERT into request_details (request_id,serial_number,amount) values ";
			$id = $row["LAST_INSERT_ID()"];
			$data = "";
			for($i=0;$i<sizeof($batches);$i++) {
				$ro = explode("^", $batches[$i]);
				$data = $data."("."'".$id."'".","."'".$ro[0]."'".","."'".$ro[1]."'"."),";
			}
			$data = substr($data,0,-1);
			$query = $query.$data.";";
			$res = mysqli_query($conn,$query);
			if($res){
				$ret = "ok";
			}
		}
		
	}
	echo $ret;
	exit();
}


?>