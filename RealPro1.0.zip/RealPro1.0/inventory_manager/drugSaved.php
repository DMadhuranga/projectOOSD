<?php
echo "Drug Added";

?>