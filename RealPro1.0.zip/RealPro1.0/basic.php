<?php
session_start();
include('dbconnection.php'); //$conn
include('User.php');
include('basicTemp.php');

if(!isset($_SESSION['logged']) || !isset($_SESSION['user'])){
	header('location:login.php');
}
$pages = $_SESSION['pages'];
?>


<html>
<head>

</head>
<body>
<div class='container-fluid'>
	<div class='row'>
	  <div class='col-md-2 col-md-2-height1'>
    <div class = "row">
		<ul class="nav nav-pills nav-stacked">
      <?php
      foreach( $pages as $tempPag ) {?>
        <li><a href="<?php echo $tempPag[1]; ?>"><?php echo $tempPag[0]; ?></a></li>
      <?php      
      }; 
?>
		</ul>
		</div>
	  </div>
	  <div class='col-md-10'>
    <div class="row">
	  <!-- Put Anything-->
	  
	  
	  
	  <!-- Put Anything-->
    </div>
	  </div>
	</div>
</div>
</body>
</html>


